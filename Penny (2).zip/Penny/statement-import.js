'use strict';

const HdfcStatement = (() => {
  const datePattern = /^\d{2}\/\d{2}\/(?:\d{2}|\d{4})$/;
  const amountPattern = /^(?:\d{1,3}(?:,\d{2,3})+|\d+)\.\d{2}$/;

  function parseDate(value) {
    if (!datePattern.test(value)) throw new Error(`Invalid transaction date: ${value}`);
    const [day, month, rawYear] = value.split('/');
    const year = rawYear.length === 2 ? `20${rawYear}` : rawYear;
    const iso = `${year}-${month}-${day}`;
    const date = new Date(`${iso}T12:00:00`);
    if (!Number.isFinite(date.getTime()) || date.getFullYear() !== Number(year) ||
        date.getMonth() + 1 !== Number(month) || date.getDate() !== Number(day)) {
      throw new Error(`Invalid transaction date: ${value}`);
    }
    return iso;
  }

  function parseAmount(value) {
    const text = value.replace(/\s+/g, '');
    if (!amountPattern.test(text)) throw new Error(`Unrecognised amount: ${value}`);
    const [rupees, paise] = text.replace(/,/g, '').split('.');
    const result = Number(rupees) * 100 + Number(paise);
    if (!Number.isSafeInteger(result) || result > 999999999) throw new Error(`Amount is outside Penny's supported range: ${value}`);
    return result;
  }

  function linesFromItems(items) {
    const lines = [];
    for (const item of items) {
      if (!item.str || !item.str.trim()) continue;
      const y = item.transform[5];
      let line = lines.find(candidate => Math.abs(candidate.y - y) < 2);
      if (!line) { line = {y, items:[]}; lines.push(line); }
      line.items.push({text:item.str.trim(), x:item.transform[4], width:item.width});
    }
    for (const line of lines) line.items.sort((a,b) => a.x-b.x);
    return lines.sort((a,b) => b.y-a.y);
  }

  function findColumns(lines) {
    for (let index = 0; index < lines.length; index++) {
      const region = lines.slice(index,index+3).filter(line=>lines[index].y-line.y<=30);
      const words = [];
      for (const line of region) for (const item of line.items) {
        const matches = [...item.text.matchAll(/\S+/g)];
        for (const match of matches) words.push({
          text:match[0].toLowerCase().replace(/[^a-z]/g,''),
          x:item.x + item.width * match.index / item.text.length,
          y:line.y
        });
      }
      const find = name => words.find(word=>word.text===name);
      const date = find('date');
      const narration = find('narration');
      const withdrawal = find('withdrawal');
      const deposit = find('deposit');
      const closing = find('closing');
      if (date && narration && withdrawal && deposit && closing &&
          date.x < narration.x && narration.x < withdrawal.x &&
          withdrawal.x < deposit.x && deposit.x < closing.x) {
        return {start:index, end:index+1, date:date.x, narration:narration.x,
          withdrawal:withdrawal.x, deposit:deposit.x, closing:closing.x};
      }
    }
    return null;
  }

  function inColumn(items, min, max) {
    return items.filter(item => item.x >= min && item.x < max).map(item=>item.text).join(' ').trim();
  }

  function parsePages(pages) {
    const rows = [];
    let sawHeader = false;
    for (let pageIndex=0; pageIndex<pages.length; pageIndex++) {
      const lines = linesFromItems(pages[pageIndex]);
      const columns = findColumns(lines);
      if (!columns) {
        if (lines.some(line=>line.items.some(item=>datePattern.test(item.text)))) {
          throw new Error(`Page ${pageIndex+1} contains dates but its transaction columns could not be identified. No rows were imported.`);
        }
        continue;
      }
      sawHeader = true;
      const boundary = (a,b) => (a+b)/2;
      const dateEnd = boundary(columns.date,columns.narration);
      const narrationEnd = columns.withdrawal - 4;
      const withdrawalEnd = columns.deposit - 4;
      const depositEnd = columns.closing - 4;
      let row = null;
      let lastY = null;
      function finish() {
        if (!row) return;
        const debit = row.withdrawal.trim();
        const credit = row.deposit.trim();
        if (!!debit === !!credit) throw new Error(`Page ${pageIndex+1}, ${row.date}: expected exactly one withdrawal or deposit. No rows were imported.`);
        if (!row.description.trim()) throw new Error(`Page ${pageIndex+1}, ${row.date}: transaction description is missing. No rows were imported.`);
        const amount = parseAmount(debit || credit);
        if (amount === 0) throw new Error(`Page ${pageIndex+1}, ${row.date}: zero-value transaction cannot be imported.`);
        rows.push({date:parseDate(row.date), description:row.description.trim().replace(/\s+/g,' '),
          direction:debit?'debit':'credit', amount,
          closing:row.closing ? parseAmount(row.closing) : null, page:pageIndex+1});
        row = null;
      }
      for (const line of lines.slice(columns.end)) {
        const date = inColumn(line.items,columns.date-10,dateEnd);
        const description = inColumn(line.items,dateEnd,narrationEnd);
        const debit = inColumn(line.items,narrationEnd,withdrawalEnd);
        const credit = inColumn(line.items,withdrawalEnd,depositEnd);
        const closing = inColumn(line.items,depositEnd,Infinity);
        if (datePattern.test(date)) {
          finish();
          row = {date,description,withdrawal:debit,deposit:credit,closing};
          lastY = line.y;
        } else if (row && lastY-line.y <= 18 && !date && !debit && !credit && !closing && description) {
          row.description += ` ${description}`;
          lastY = line.y;
        } else if (row && (debit || credit || closing)) {
          finish();
        }
      }
      finish();
    }
    if (!sawHeader) throw new Error('Could not find HDFC transaction columns. This may be a scanned PDF or an unsupported statement layout. No rows were imported.');
    if (!rows.length) throw new Error('No transactions were found. Check the statement period and whether the PDF contains selectable text.');
    return rows;
  }

  async function readPdf(file,password) {
    if (!window.pdfjsLib) throw new Error('The local PDF reader is missing. Keep the vendor folder beside index.html.');
    if (file.size > 20 * 1024 * 1024) throw new Error('This PDF is larger than 20 MB. Please export a shorter statement.');
    pdfjsLib.GlobalWorkerOptions.workerSrc = 'vendor/pdf.worker.min.js';
    const task = pdfjsLib.getDocument({data:await file.arrayBuffer(), password:password || undefined, isEvalSupported:false});
    let pdf;
    try {
      pdf = await task.promise;
      if (pdf.numPages > 100) throw new Error('This PDF has more than 100 pages. Please export a shorter statement.');
      const pages = [];
      for (let page=1; page<=pdf.numPages; page++) {
        const content = await (await pdf.getPage(page)).getTextContent();
        pages.push(content.items);
      }
      return parsePages(pages);
    } finally {
      await task.destroy();
    }
  }
  return {parsePages,readPdf};
})();
