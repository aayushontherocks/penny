# Penny

Open `index.html` in your browser. Keep `statement-import.js` and the `vendor`
folder next to it; they provide the local PDF reader. If sharing Penny, send the
whole folder, not just `index.html`.

## Import an HDFC statement

1. Download a **text-based** HDFC account-statement PDF. Scanned images and
   photos are not supported. PDF layouts differ; this importer recognises
   statements with Date, Narration, Withdrawal, Deposit and Closing Balance
   headings. Other formats may need changes.
2. Click **Import PDF**, choose the file, and enter its password if needed.
3. Click **Read statement**. The file is processed locally, not uploaded.
4. Compare **every row**, including date, direction and amount, against the
   original statement. Correct the date, amount and name if needed, choose
   categories and types, and uncheck any entries you do not want.
5. Confirm that you checked the entries, then click **Import selected** and
   confirm. Any rows that could be duplicates or have a balance warning start
   unchecked. A manually entered transaction may still be a duplicate even
   if it is not detected.

The importer does not automatically distinguish salary, refunds, transfers
between your accounts, card-bill payments, or investments. Review these
carefully and exclude internal transfers or double-counted card payments when
appropriate. The imported credit list lets you remove a credit if necessary.
Duplicate detection uses the original date, amount, direction and description.
Identical transactions can be distinct, and overlapping statements with changed
descriptions can escape detection.

On the first confirmed import, Penny switches to **actual credits**: the saved
planned salary remains in settings but is not added automatically. Monthly net
is credits recorded in that month minus outgoings recorded in that month. It
is **not** your bank balance: opening balance, other months, excluded rows and
untracked accounts are not included. Both salary and refunds appear as credits.

Existing data remains in the same browser's local storage. Clearing browser
site data may erase it. Do not send anyone your PDF password, OTP, UPI PIN or
an unredacted statement. Penny's CSV export exports the currently shown entry
type and month; it is not a full restorable backup.

Penny bundles Mozilla PDF.js 3.11.174 for PDF reading; its Apache 2.0 license
is in `vendor/PDFJS-LICENSE.txt`.
