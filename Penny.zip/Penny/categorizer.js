'use strict';

// On-device categoriser: learns from your own labelled entries (exact payee memory
// plus a naive Bayes text model) and falls back to common Indian merchant keywords.
// Nothing here makes network requests.
const PennyCategorizer = (() => {
  const STOPWORDS = new Set(('upi neft imps rtgs ach pos ref payment from phone paid via the and for '+
    'txn transfer hdfc hdfcbank okhdfcbank okicici okaxis oksbi ybl ibl axl apl paytm bank india pvt '+
    'ltd limited private sent using collect request mandate mobile app net banking ecom online inr').split(' '));

  const KEYWORDS = {
    'expense:food': ['swiggy','zomato','blinkit','zepto','bigbasket','instamart','dominos','mcdonalds','kfc',
      'starbucks','restaurant','cafe','bakery','dmart','grocery','groceries','supermarket','kirana','chaayos','haldiram'],
    'expense:shopping': ['amazon','flipkart','myntra','ajio','nykaa','meesho','decathlon','croma','westside',
      'lifestyle','tatacliq','reliance digital','lenskart','firstcry'],
    'expense:transport': ['uber','ola','rapido','irctc','metro','fastag','petrol','fuel','hpcl','bpcl','iocl',
      'indianoil','redbus','indigo','parking','airline','railway'],
    'expense:entertainment': ['netflix','spotify','hotstar','bookmyshow','pvr','inox','youtube','sonyliv','zee5',
      'steam','playstation','jiocinema','gaana'],
    'expense:home': ['electricity','bescom','msedcl','tatapower','tata power','adani electricity','airtel','jio',
      'vodafone','bsnl','fibernet','broadband','rent','maintenance','indane','bharat gas','water bill','nobroker','society'],
    'investment': ['zerodha','groww','upstox','kuvera','mutual fund','sip','nps','ppf','smallcase','etmoney',
      'indian clearing','iccl','bse star','nse clearing','angel one','paytm money','coin by zerodha']
  };

  function tokenize(text) {
    return String(text).toLowerCase().split(/[^a-z]+/).filter(token=>token.length>=3 && !STOPWORDS.has(token));
  }

  const titleCase = text => text.toLowerCase().replace(/\b[a-z]/g, char=>char.toUpperCase());

  function parsePayee(description) {
    const text = String(description).trim();
    const vpa = (text.match(/[a-z0-9._]+@[a-z]{2,}/i) || [])[0];
    const patterns = [
      /^UPI-([^-]+)-/i,
      /^(?:NEFT|RTGS|IMPS)\s*(?:CR|DR)?\s*-[^-]*-([^-]+)/i,
      /^ACH\s*[DC]\s*-\s*([^-]+)/i,
      /^POS\s+\S+\s+(.+)$/i
    ];
    let name = '';
    for (const pattern of patterns) {
      const match = text.match(pattern);
      if (match && /[a-z]/i.test(match[1])) { name = match[1]; break; }
    }
    if (!name) name = text.replace(/\b\d{6,}\b/g,'').replace(/[a-z0-9._]+@[a-z]{2,}/ig,'');
    name = titleCase(name.replace(/\s+/g,' ').trim()).slice(0,100) || text.slice(0,100);
    const key = (vpa || name).toLowerCase().replace(/\s+/g,' ').trim();
    return {name, key};
  }

  function labelOf(entry) {
    return entry.type === 'expense' ? `expense:${entry.category}` : entry.type;
  }

  function train(examples) {
    const payees = new Map();
    const labelDocs = new Map();
    const tokenCounts = new Map();
    const vocabulary = new Set();
    for (const example of examples) {
      payees.set(parsePayee(example.text).key, example.label);
      const tokens = tokenize(example.text);
      labelDocs.set(example.label, (labelDocs.get(example.label) || 0) + 1);
      if (!tokenCounts.has(example.label)) tokenCounts.set(example.label, {total:0, counts:new Map()});
      const bucket = tokenCounts.get(example.label);
      for (const token of tokens) {
        vocabulary.add(token);
        bucket.total++;
        bucket.counts.set(token, (bucket.counts.get(token) || 0) + 1);
      }
    }
    const documents = examples.length;

    function bayes(description) {
      const tokens = tokenize(description).filter(token=>vocabulary.has(token));
      if (documents < 3 || !tokens.length) return null;
      const scores = [...labelDocs].map(([label, count]) => {
        const bucket = tokenCounts.get(label);
        let score = Math.log(count / documents);
        for (const token of tokens) score += Math.log(((bucket.counts.get(token) || 0) + 1) / (bucket.total + vocabulary.size));
        return {label, score};
      });
      const max = Math.max(...scores.map(item=>item.score));
      const total = scores.reduce((sum,item)=>sum+Math.exp(item.score-max),0);
      const best = scores.sort((a,b)=>b.score-a.score)[0];
      return {label:best.label, confidence:1/total};
    }

    function keyword(description) {
      const text = ` ${String(description).toLowerCase().replace(/[^a-z]+/g,' ')} `;
      for (const [label, words] of Object.entries(KEYWORDS)) {
        if (words.some(word=>text.includes(` ${word} `))) return label;
      }
      return null;
    }

    function predict(description) {
      const payee = parsePayee(description);
      const remembered = payees.get(payee.key);
      if (remembered) return {label:remembered, confidence:0.95, source:'payee', payee};
      const learned = bayes(description);
      if (learned && learned.confidence >= 0.7) return {...learned, source:'learned', payee};
      const matched = keyword(description);
      if (matched) return {label:matched, confidence:0.8, source:'keyword', payee};
      return {label:null, confidence:0, source:'none', payee};
    }

    return {predict, size:documents};
  }

  // Bank description is kept in `note` for imported rows; manual rows use name + note.
  function examplesFromEntries(entries) {
    return entries.filter(entry=>!entry.demo).slice().sort((a,b)=>a.date.localeCompare(b.date)).map(entry=>({
      text: entry.importKey ? entry.note : `${entry.name} ${entry.destination} ${entry.note}`,
      label: labelOf(entry)
    })).filter(example=>example.text.trim());
  }

  return {train, examplesFromEntries, parsePayee, tokenize};
})();
