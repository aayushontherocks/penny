# Penny

Open `index.html` in your browser. Keep `statement-import.js`, `categorizer.js`
and the `vendor` folder next to it; they provide the local PDF reader and
categoriser. If sharing Penny, send the whole folder, not just `index.html`.

## Import an HDFC statement

1. Download a **text-based** HDFC account-statement PDF. Scanned images and
   photos are not supported. PDF layouts differ; this importer recognises
   statements with Date, Narration, Withdrawal, Deposit and Closing Balance
   headings. Continuation pages without repeated headings and the final
   statement-summary page are handled. Any dated line that cannot be read is
   listed after reading so you can add it manually.
2. Click **Import PDF**, choose the file, and enter its password if needed.
3. Click **Read statement**. The file is processed locally, not uploaded.
4. Compare **every row**, including date, direction and amount, against the
   original statement. Correct the date, amount and name if needed, check the
   suggested categories and types, and uncheck any entries you do not want.
5. Confirm that you checked the entries, then click **Import selected** and
   confirm. Any rows that could be duplicates or have a balance warning start
   unchecked. A manually entered transaction may still be a duplicate even
   if it is not detected.

Where closing balances are present, Penny uses the running balance to confirm
whether each row is a debit or credit.

## Category suggestions (on-device)

Penny suggests a payee name, type and category for each debit. Nothing is sent
to any server. Suggestions come from, in order:

1. **Same payee as before** — the UPI ID or payee name matches an entry you
   saved; your most recent choice is reused.
2. **Learned patterns** — a small naive Bayes model trained in your browser on
   your saved, non-sample entries. It is used only when it is at least 70%
   confident.
3. **Known merchants** — a built-in list of common Indian merchants, such as
   Swiggy, Uber and Zerodha.

Otherwise the row says **No suggestion**. When you change a row's type or
category during review, Penny applies the same choice to other rows with the
same payee that you have not changed. Suggestions improve as you import and
correct more transactions. They can be wrong, so always review them.

The importer cannot reliably distinguish salary from refunds, transfers
between your accounts, or card-bill payments. Review these carefully and
exclude internal transfers or double-counted card payments when appropriate.
The imported credit list lets you remove a credit if necessary.
Duplicate detection uses the original date, amount, direction and description.
Identical transactions can be distinct, and overlapping statements with changed
descriptions can escape detection.

On the first confirmed import, Penny switches to **actual credits**: the saved
planned salary remains in settings but is not added automatically. Monthly net
is credits recorded in that month minus outgoings recorded in that month. It
is **not** your bank balance: opening balance, other months, excluded rows and
untracked accounts are not included. Both salary and refunds appear as credits.

Existing data remains in the same browser's local storage. Clearing browser
site data may erase it. Do not send anyone your PDF password, OTP, UPI PIN or
an unredacted statement. Penny's CSV export exports the currently shown entry
type and month; it is not a full restorable backup.

Penny bundles Mozilla PDF.js 3.11.174 for PDF reading; its Apache 2.0 license
is in `vendor/PDFJS-LICENSE.txt`.
