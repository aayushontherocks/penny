'use strict';

const HdfcStatement = (() => {
  const datePattern = /^\d{2}\/\d{2}\/(?:\d{2}|\d{4})$/;
  const amountPattern = /^(?:\d{1,3}(?:,\d{2,3})+|\d+)\.\d{2}$/;

  function parseDate(value) {
    if (!datePattern.test(value)) throw new Error(`Invalid transaction date: ${value}`);
    const [day, month, rawYear] = value.split('/');
    const year = rawYear.length === 2 ? `20${rawYear}` : rawYear;
    const iso = `${year}-${month}-${day}`;
    const date = new Date(`${iso}T12:00:00`);
    if (!Number.isFinite(date.getTime()) || date.getFullYear() !== Number(year) ||
        date.getMonth() + 1 !== Number(month) || date.getDate() !== Number(day)) {
      throw new Error(`Invalid transaction date: ${value}`);
    }
    return iso;
  }

  function parseAmount(value) {
    const text = value.replace(/\s+/g, '');
    if (!amountPattern.test(text)) throw new Error(`Unrecognised amount: ${value}`);
    const [rupees, paise] = text.replace(/,/g, '').split('.');
    const result = Number(rupees) * 100 + Number(paise);
    if (!Number.isSafeInteger(result) || result > 999999999) throw new Error(`Amount is outside Penny's supported range: ${value}`);
    return result;
  }

  function linesFromItems(items) {
    const lines = [];
    for (const item of items) {
      if (!item.str || !item.str.trim()) continue;
      const y = item.transform[5];
      let line = lines.find(candidate => Math.abs(candidate.y - y) < 2);
      if (!line) { line = {y, items:[]}; lines.push(line); }
      line.items.push({text:item.str.trim(), x:item.transform[4], width:item.width});
    }
    for (const line of lines) line.items.sort((a,b) => a.x-b.x);
    return lines.sort((a,b) => b.y-a.y);
  }

  function findColumns(lines) {
    for (let index = 0; index < lines.length; index++) {
      const region = lines.slice(index,index+3).filter(line=>lines[index].y-line.y<=30);
      const words = [];
      for (const line of region) for (const item of line.items) {
        const matches = [...item.text.matchAll(/\S+/g)];
        for (const match of matches) {
          const x = item.x + item.width * match.index / item.text.length;
          words.push({text:match[0].toLowerCase().replace(/[^a-z]/g,''), x,
            center:x + item.width * match[0].length / item.text.length / 2});
        }
      }
      const find = (...names) => words.find(word=>names.includes(word.text));
      const date = find('date');
      const narration = find('narration','description','particulars');
      const withdrawal = find('withdrawal','withdrawals','debit','debits');
      const deposit = find('deposit','deposits','credit','credits');
      const closing = find('closing','balance');
      if (date && narration && withdrawal && deposit && closing &&
          date.x < narration.x && narration.x < withdrawal.x &&
          withdrawal.x < deposit.x && deposit.x < closing.x) {
        const between = words.filter(word=>word.x>narration.x+5 && word.x<withdrawal.x-5 && /^(chq|ref|value|cheque)/.test(word.text));
        const narrationEnd = between.length ? Math.min(...between.map(word=>word.x)) - 4 : withdrawal.x - 4;
        return {end:index+1, date:date.x, narration:narration.x, narrationEnd,
          withdrawal:withdrawal.center, deposit:deposit.center, closing:closing.center,
          reach:withdrawal.x - (deposit.x - withdrawal.x)};
      }
    }
    return null;
  }

  const joinText = items => items.map(item=>item.text).join(' ').replace(/\s+/g,' ').trim();

  function readLine(line, columns) {
    const dateEnd = (columns.date + columns.narration) / 2;
    const dateText = joinText(line.items.filter(item=>item.x < dateEnd));
    const description = joinText(line.items.filter(item=>item.x >= dateEnd && item.x < columns.narrationEnd));
    const amounts = {withdrawal:[], deposit:[], closing:[]};
    for (const item of line.items) {
      const value = item.text.replace(/\s+/g,'').replace(/(Cr|Dr)$/i,'');
      if (!amountPattern.test(value) || item.x < columns.reach) continue;
      const center = item.x + item.width/2;
      const nearest = ['withdrawal','deposit','closing']
        .map(name=>({name, distance:Math.abs(columns[name]-center)}))
        .sort((a,b)=>a.distance-b.distance)[0].name;
      amounts[nearest].push(value);
    }
    return {dateText, description, amounts, hasAmount:Object.values(amounts).some(list=>list.length)};
  }

  function parsePages(pages) {
    const rows = [];
    const skipped = [];
    let columns = null;
    for (let pageIndex=0; pageIndex<pages.length; pageIndex++) {
      const lines = linesFromItems(pages[pageIndex]);
      const found = findColumns(lines);
      // Continuation pages often omit the header, so reuse the last known layout.
      if (found) columns = found;
      if (!columns) continue;
      let row = null;
      let lastY = null;
      function finish() {
        if (!row) return;
        const current = row;
        row = null;
        const {withdrawal, deposit, closing} = current.amounts;
        try {
          if (withdrawal.length + deposit.length !== 1 || closing.length > 1) throw new Error('expected exactly one withdrawal or deposit');
          const amount = parseAmount(withdrawal[0] || deposit[0]);
          if (amount === 0) throw new Error('zero-value transaction');
          rows.push({date:parseDate(current.date), description:current.description || 'No description',
            direction:withdrawal.length ? 'debit' : 'credit', amount,
            closing:closing.length ? parseAmount(closing[0]) : null, page:pageIndex+1, corrected:false});
        } catch (error) {
          skipped.push({page:pageIndex+1, text:`${current.date} ${current.description}`.trim(), reason:error.message});
        }
      }
      for (const line of lines.slice(found ? found.end : 0)) {
        if (/statement\s+summary/i.test(joinText(line.items))) break;
        const parsed = readLine(line, columns);
        const date = parsed.dateText.split(' ')[0];
        if (datePattern.test(date) && parsed.hasAmount) {
          finish();
          row = {date, description:parsed.description, amounts:parsed.amounts};
          lastY = line.y;
        } else if (row && lastY-line.y <= 18 && !parsed.dateText && !parsed.hasAmount && parsed.description) {
          row.description = `${row.description} ${parsed.description}`.trim();
          lastY = line.y;
        } else {
          finish();
        }
      }
      finish();
    }
    // A running balance proves direction: fix rows where column geometry disagreed.
    for (let i=1; i<rows.length; i++) {
      const previous = rows[i-1].closing, row = rows[i];
      if (previous === null || row.closing === null) continue;
      const direction = previous - row.amount === row.closing ? 'debit' : previous + row.amount === row.closing ? 'credit' : null;
      if (direction && direction !== row.direction) { row.direction = direction; row.corrected = true; }
    }
    if (!columns) throw new Error('Could not find transaction columns (Date, Narration, Withdrawal, Deposit, Balance). This may be a scanned PDF or an unsupported layout.');
    if (!rows.length) throw new Error('No transactions were found. Check the statement period and whether the PDF contains selectable text.');
    return {rows, skipped};
  }

  async function readPdf(file,password) {
    if (!window.pdfjsLib) throw new Error('The local PDF reader is missing. Keep the vendor folder beside index.html.');
    if (file.size > 20 * 1024 * 1024) throw new Error('This PDF is larger than 20 MB. Please export a shorter statement.');
    pdfjsLib.GlobalWorkerOptions.workerSrc = 'vendor/pdf.worker.min.js';
    const task = pdfjsLib.getDocument({data:await file.arrayBuffer(), password:password || undefined, isEvalSupported:false});
    let pdf;
    try {
      pdf = await task.promise;
      if (pdf.numPages > 100) throw new Error('This PDF has more than 100 pages. Please export a shorter statement.');
      const pages = [];
      for (let page=1; page<=pdf.numPages; page++) {
        const content = await (await pdf.getPage(page)).getTextContent();
        pages.push(content.items);
      }
      return parsePages(pages);
    } finally {
      await task.destroy();
    }
  }
  return {parsePages,readPdf};
})();
